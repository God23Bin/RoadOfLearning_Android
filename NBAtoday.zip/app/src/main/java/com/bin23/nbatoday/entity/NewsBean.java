//package com.bin23.nbatoday.entity;
//
//import android.graphics.drawable.Drawable;
//
//public class NewsBean {
//    private String newsTitle;
//    private String newsDes;
//    private int newsPic;
//    private String newsUrl;
//
//    public NewsBean() {
//    }
//
//    public NewsBean(String newsTitle, String newsDes, int newsPic, String newsUrl) {
//        this.newsTitle = newsTitle;
//        this.newsDes = newsDes;
//        this.newsPic = newsPic;
//        this.newsUrl = newsUrl;
//    }
//
//    public String getNewsTitle() {
//        return newsTitle;
//    }
//
//    public void setNewsTitle(String newsTitle) {
//        this.newsTitle = newsTitle;
//    }
//
//    public String getNewsDes() {
//        return newsDes;
//    }
//
//    public void setNewsDes(String newsDes) {
//        this.newsDes = newsDes;
//    }
//
//    public int getNewsPic() {
//        return newsPic;
//    }
//
//    public void setNewsPic(int newsPic) {
//        this.newsPic = newsPic;
//    }
//
//    public String getNewsUrl() {
//        return newsUrl;
//    }
//
//    public void setNewsUrl(String newsUrl) {
//        this.newsUrl = newsUrl;
//    }
//}
